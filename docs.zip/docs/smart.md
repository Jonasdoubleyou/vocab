# Smart
## Gruppemitglieder
Alexander, Jonas

## Thema/Titel
Eine Flashkarten-Anwendung in React

## SMART-Ziel des Projektes
### Spezifisch
Eine Anwendung zur welcher man Vokabeln hinzufügen kann, welche
per SuperMemo2 in verschiedenen Intervallen (Abhängig von der Antwort) abgefragt werden.

### Messbar
Der Lernerfolg bei Verwendung der Anwendung

### Attraktiv
Ja, da das Vokabellernen ein essentieller Bestandteil eines jeden Fremdsprachenunterrichts ist.

### Realistisch
Das Ziel lässt sich in dem vorgegebenen Zeitrahmen lösen, unter der Verwendung von Technologien
wie Codesandbox, React und TypeScript.

### Terminiert
Sobald die Funktionaliät des Hinzufügen und Abfragen von Vokabeln implementiert ist, kann das
Projekt als terminiert betrachtet werden.