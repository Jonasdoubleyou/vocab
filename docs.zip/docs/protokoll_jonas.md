# Protokoll
## 7.6
### Erledigte Aufgaben
grundlegende UI
- Hauptmenu
- Tabs
- Zustandsspeicher

## 12.06
### Erledigte Aufgaben
- Menü zum erstellen neuer Listen

## 14.06
### Erledigte Aufgaben
- Komponente zum Hinzufügen neuer Karten zu einer Liste (AddCard Component)
- Karten können angezeigt werden (CardList Component)
- Listen können ausgewählt werden (Lists Component)

## 14.08
### Erledigte Aufgaben
- Besseres Feedback bei Review (correct / nearly / wrong)
- bugfixes:
  - Hinzufügen von Karten wurde nicht in der aktuellen Liste übernommen
  - Wechsel der Liste gng nicht
  
