# Vocab - Ein Vokabel-SRS
## Beschreibung
Vocab soll eine Anwendung sein, welche es dem User erlaubt, Vokabeln in  benutzererstellte
Listen einzutragen und diese dann effizient zu lernen.
Dafür wird der SuperMemo2-Algorithmus verwendet, um zu ermitteln, wann eine Vokabel am Besten
wiederholt werden sollte.

Damit die Vokabelabfrage effizienter wird, soll der User die Antwort der Frage, also
"Fremdsprache - Muttersprache" oder "Muttersprache - Fremdsprache", eigenständig
eingeben.
Als erweitertes Ziel soll ermittelt werden, die unterschiedlich die Eingabe und die eigentliche
Antwort sind, um so dem SuperMemo2-Algorithmus zu sagen, dass der User die Antwort teilweise noch weiß
und so die Antwort später abgefragt wird, als wenn er die Antwort nicht gewusst hätte, aber früher, als wenn
er die Antwort gewusst hätte.