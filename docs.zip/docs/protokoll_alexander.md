# Protokoll
## 07.06.2018
### Erledigte Aufgaben
- Implementierung des SuperMemo2-Algorithmus
- Erstellen der zugrundeliegenden Datenstrukuren

### TODO

## 12.6.2018
### Erledigte Aufgaben
- Grundelegende Review-Seite

### TODO
- Review fertig machen

## 14.06.2018
### Erledigte Aufgaben
- weiteres ausbauen der Review-Seite
- verschönern der Seiten durch einen Drawer

### TODO
- Funktionalität der Review-Seite

## 19.06.2018
### Erledigte Aufgaben
- Verbessern des "Card Adders"
- Fertigstellen der Review-Seite
- Implementieren einer Funktion zum Ermitteln der zu wiederholenden Karten
- Implentieren der Levenstein Distance

## 21.06.2018
### Erledigte Aufgaben
- Korrektes Implementieren der Levenshtein-Distanz 

## 14.08
### Erledigte Aufgaben
- bug fixes
  - Drawer ging be einigen Menüpunkten nicht zu
  - fehlerhafte UI
  - Beheben von korruptem Code 
